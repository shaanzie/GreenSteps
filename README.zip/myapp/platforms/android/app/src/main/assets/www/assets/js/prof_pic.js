var firebaseConfig = {
    apiKey: "AIzaSyAGdIIE4HmuF5hhCLky5V5llWui1lRGhLo",
    authDomain: "greensteps-8f852.firebaseapp.com",
    databaseURL: "https://greensteps-8f852.firebaseio.com",
    projectId: "greensteps-8f852",
    storageBucket: "",
    messagingSenderId: "401433379611",
    appId: "1:401433379611:web:5159a5c926ecd0b4"
    };
    // Initialize Firebase
firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();

var email = window.sessionStorage.getItem('Name');

// db.collection("Users").where('Email', '==', email).get().then((querySnapshot) => {
//     var img_prof = document.getElementById('prof');
//     querySnapshot.forEach((doc) => {
//     img_prof.setAttribute('src', doc.data()['ProfilePicture']);
//     // console.log(doc.data()['ProfilePicture']);
//     });
// });
img_prof.setAttribute('src',"https://cdn.pixabay.com/photo/2016/10/09/18/03/smile-1726471_960_720.jpg");
$(document).ready(function() {
    var arr;
db.collection("Users").where('Email', '==', email).get().then((querySnapshot) => {
var img_prof = document.getElementById('prof_pic');
var name = document.getElementById('username');
var buses = document.getElementById('BusNo');
var score = document.getElementById('Score');
var fuel = document.getElementById('Fuel');
var money = document.getElementById('money');
var graph_fuel = document.getElementById('litres');
var graph_money = document.getElementById('MoneySaved');

querySnapshot.forEach((doc) => {
    img_prof.setAttribute('src', doc.data()['ProfilePicture']);
    name.innerHTML = doc.data()['Name'];
    buses.innerHTML = doc.data()['BusNo'];
    score.innerHTML = doc.data()['Score'];
    fuel.innerHTML = window.localStorage.getItem('FuelSum');
    // money.innerHTML = doc.data()['MoneySaved'];

    
    
    mon = doc.data()['MoneySaved'];
    var sum = 0;
    mon.forEach(element => {
       sum+=element 
    });
    fuel = doc.data()['FuelSaved'];
    var sum2 = 0;
    fuel.forEach(element => {
       sum2+=element 
    });
    graph_fuel.innerHTML = '<i class="tim-icons icon-bell-55 text-primary "></i>' + sum2 + " L";
    MoneySaved.innerHTML = '<i class="tim-icons icon-send text-success "></i>' + sum + " INR";

});
});
    
});