var firebaseConfig = {
    apiKey: "AIzaSyAGdIIE4HmuF5hhCLky5V5llWui1lRGhLo",
    authDomain: "greensteps-8f852.firebaseapp.com",
    databaseURL: "https://greensteps-8f852.firebaseio.com",
    projectId: "greensteps-8f852",
    storageBucket: "",
    messagingSenderId: "401433379611",
    appId: "1:401433379611:web:5159a5c926ecd0b4"
    };
    // Initialize Firebase
firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();


function send() {
    var sub = document.getElementById('sub').value;
var city = document.getElementById('city').value;
var desc = document.getElementById('desc').value;
db.collection('Feedback').doc().set({
    'Subject': sub,
    'City': city,
    'Description': desc
})
.then(function() {
    console.log("Document successfully written!");
})
.catch(function(error) {
    console.error("Error writing document: ", error);
});
}