/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
var app = {
    // Application Constructor
    initialize: function() {
        document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
    },

    // deviceready Event Handler
    //
    // Bind any cordova events here. Common events are:
    // 'pause', 'resume', etc.
    onDeviceReady: function() {
        this.receivedEvent('deviceready');
        // document.querySelector("#prepare").addEventListener("touchend", function() {
        //     window.QRScanner.prepare(onDone); // show the prompt
        // });
            window.QRScanner.show();
            window.QRScanner.scan(displayContents);
        function displayContents(err, text){
            if(err){
                // an error occurred, or the scan was canceled (error code `6`)
            } else {
                // The scan completed, display the contents of the QR code:
                var firebaseConfig = {
                    apiKey: "AIzaSyAGdIIE4HmuF5hhCLky5V5llWui1lRGhLo",
                    authDomain: "greensteps-8f852.firebaseapp.com",
                    databaseURL: "https://greensteps-8f852.firebaseio.com",
                    projectId: "greensteps-8f852",
                    storageBucket: "",
                    messagingSenderId: "401433379611",
                    appId: "1:401433379611:web:5159a5c926ecd0b4"
                    };
                    // Initialize Firebase
                firebase.initializeApp(firebaseConfig);
                var db = firebase.firestore();
                db.collection("Users").where('Email', '==', window.sessionStorage.Name).get().then((querySnapshot) => {
                    querySnapshot.forEach((doc) => {
                    window.localStorage.setItem("score", doc.data()['Score']);
                });
                });
                alert(text);
                window.QRScanner.cancelScan();
                window.location.href="spinner.html";
            }
        }
    },

    // Update DOM on a Received Event
    receivedEvent: function(id) {
        console.log('Received Event: ' + id);
    }
};

app.initialize();