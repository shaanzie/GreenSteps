// var firebaseConfig = {
//     apiKey: "AIzaSyAGdIIE4HmuF5hhCLky5V5llWui1lRGhLo",
//     authDomain: "greensteps-8f852.firebaseapp.com",
//     databaseURL: "https://greensteps-8f852.firebaseio.com",
//     projectId: "greensteps-8f852",
//     storageBucket: "",
//     messagingSenderId: "401433379611",
//     appId: "1:401433379611:web:5159a5c926ecd0b4"
//     };
//     // Initialize Firebase
// firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();

var email = window.sessionStorage.getItem('Name');

db.collection("Users").where('Email', '==', email).get().then((querySnapshot) => {
    var img_prof = document.getElementById('prof');
    querySnapshot.forEach((doc) => {
    img_prof.setAttribute('src', doc.data()['ProfilePicture']);
    // console.log(doc.data()['ProfilePicture']);
    });
});


db.collection("Users").where('Email', '==', email).get().then((querySnapshot) => {
var img_prof = document.getElementById('prof_pic');
var name = document.getElementById('username');
var buses = document.getElementById('BusNo');
var score = document.getElementById('Score');
var fuel = document.getElementById('Fuel');
var money = document.getElementById('money');
querySnapshot.forEach((doc) => {
    img_prof.setAttribute('src', doc.data()['ProfilePicture']);
    name.innerHTML = doc.data()['Name'];
    score.innerHTML = doc.data()['Score'];
    fuel.innerHTML = window.localStorage.getItem('FuelSum');
    money.innerHTML = window.localStorage.getItem('MoneySum');
    console.log(doc.data()['ProfilePicture']);
});
});