
// var firebaseConfig = {
//   apiKey: "AIzaSyAGdIIE4HmuF5hhCLky5V5llWui1lRGhLo",
//   authDomain: "greensteps-8f852.firebaseapp.com",
//   databaseURL: "https://greensteps-8f852.firebaseio.com",
//   projectId: "greensteps-8f852",
//   storageBucket: "",
//   messagingSenderId: "401433379611",
//   appId: "1:401433379611:web:5159a5c926ecd0b4"
//   };
//   // Initialize Firebase
// firebase.initializeApp(firebaseConfig);
var db = firebase.firestore();

var email = window.sessionStorage.getItem('Name');

var scoreCounter;
var moneyCounter;
var fuelCounter;
var treeCounter;

db.collection("Users").where('Email', '==', email).get().then((querySnapshot) => {


querySnapshot.forEach((doc) => {

scoreCounter = doc.data()['Score'];
// moneyCounter = doc.data()['MoneySaved'];
// fuelCounter = doc.data()['FuelSaved'];
// treeCounter = doc.data()['TreesPlanted'];
// alert(treeCounter);

window.localStorage.setItem('TreesPlanted',doc.data()['TreesPlanted']);

moneyCounter = doc.data()['MoneySaved'];
    var sum = 0;
    moneyCounter.forEach(element => {
       sum+=element 
    });
fuelCounter = doc.data()['FuelSaved'];
    var sum2 = 0;
    fuelCounter.forEach(element => {
       sum2+=element 
    });

    window.localStorage.setItem('MoneySum', sum);
    window.localStorage.setItem('FuelSum', sum2);

$('.scoreCounter').each(function() {
  var $this = $(this),
      countTo = scoreCounter;

  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 5000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  
  

});

});

$('.moneyCounter').each(function() {
  var $this = $(this),
      countTo = window.localStorage.getItem('MoneySum');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 5000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  
  

});
$('.fuelCounter').each(function() {
  var $this = $(this),
      countTo = window.localStorage.getItem('FuelSum');
  
  $({ countNum: $this.text()}).animate({
    countNum: countTo
  },

  {

    duration: 5000,
    easing:'linear',
    step: function() {
      $this.text(Math.floor(this.countNum));
    },
    complete: function() {
      $this.text(this.countNum);
      //alert('finished');
    }

  });  
  
  

});




  $('.treeCounter').each(function() {
    var $this = $(this),
        countTo = window.localStorage.TreesPlanted;
    
    $({ countNum: $this.text()}).animate({
      countNum: countTo
    },
  
    {
  
      duration: 5000,
      easing:'linear',
      step: function() {
        $this.text(Math.floor(this.countNum));
      },
      complete: function() {
        $this.text(this.countNum);
        //alert('finished');
      }
  
    });  
    
    
  });

  $('.costCounter').each(function() {
    var $this = $(this),
        countTo = window.localStorage.cost;
    
    $({ countNum: $this.text()}).animate({
      countNum: countTo
    },
  
    {
  
      duration: 5000,
      easing:'linear',
      step: function() {
        $this.text(Math.floor(this.countNum));
      },
      complete: function() {
        $this.text(this.countNum);
        //alert('finished');
      }
  
    });  
    
    
  });
  $('.fuelsCounter').each(function() {
    var $this = $(this),
        countTo = window.localStorage.fuel*1000;
    
    $({ countNum: $this.text()}).animate({
      countNum: countTo
    },
  
    {
  
      duration: 5000,
      easing:'linear',
      step: function() {
        $this.text(Math.floor(this.countNum));
      },
      complete: function() {
        $this.text(this.countNum);
        //alert('finished');
      }
  
    });  
    
    
  });
  $('.sCounter').each(function() {
    var $this = $(this),
        countTo = window.localStorage.scoreEarned;
    
    $({ countNum: $this.text()}).animate({
      countNum: countTo
    },
  
    {
  
      duration: 5000,
      easing:'linear',
      step: function() {
        $this.text(Math.floor(this.countNum));
      },
      complete: function() {
        $this.text(this.countNum);
        //alert('finished');
      }
  
    });  
    
    
  });
});

